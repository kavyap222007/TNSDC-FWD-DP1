// Simple greeting on page load (you can expand this later)

window.onload = function () {

  console.log("Portfolio Loaded Successfully!");

};